# Google-Maps-Mini-Using-Js
This is a simple project done using javascript that makes you get a feeling of a miniature version of google maps
- [Installation](#installation)
- [Sample Link](#sample-link)

## installation
To clone this project :

```bash
git clone "https://github.com/sudarsankumar/Google-Maps-Mini-Using-Js.git"
```

## demo link
[Mini Version Live Demo](https://sudarsankumar.github.io/Google-Maps-Mini-Using-Js/)