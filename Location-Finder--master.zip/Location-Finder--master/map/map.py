import speech_recognition as sr
import googlemaps
from datetime import datetime

def get_location(query):
    # Replace 'YOUR_API_KEY' with your actual Google Maps API key
    gmaps = googlemaps.Client(key='YOUR_API_KEY')

    try:
        # Geocoding API request
        geocode_result = gmaps.geocode(query)
        if geocode_result:
            location = geocode_result[0]['formatted_address']
            return location
        else:
            return "Location not found."

    except Exception as e:
        return str(e)

def main():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening for a location...")
        audio = recognizer.listen(source)

    try:
        # Use the Google Web Speech API for speech recognition
        query = recognizer.recognize_google(audio)
        print("You said: " + query)
        
        location = get_location(query)
        print("Location: " + location)

    except sr.UnknownValueError:
        print("Google Web Speech API could not understand audio")

    except sr.RequestError as e:
        print("Could not request results from Google Web Speech API; {0}".format(e))

if __name__ == "__main__":
    main()
